# A lambda function to interact with AWS RDS MySQL

import pymysql
import sys

REGION = 'eu-west-3'

rds_host  = "mysql-rds-database.clthni2agtou.eu-west-3.rds.amazonaws.com"
name = "administrator"
password = "Database33!"
db_name = "RDS"

def save_events(event):
    """
    This function fetches content from mysql RDS instance
    """
    result = []
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, database=db_name, connect_timeout=5)
    with conn.cursor() as cur:
        cur.execute("""insert into COMMENTS (id, Auteur, Comment) values( %s, '%s', '%s')""" % (event['id'], event['Auteur'], event['Comment']))
        cur.execute("""select * from COMMENTS""")
        conn.commit()
        cur.close()
        for row in cur:
            result.append(list(row))
        print ("Data for RDS...")
        print (result)

def main(event, context):
    save_events(event)
        